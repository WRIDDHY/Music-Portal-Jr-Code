# Lofi-Radio-Music-Bot
It is a discord bot bot which can play lofi song in different language 24/7. It has premium system and cool embed looks with buttons. It can play youtube songs, playlists. This bot code was made by Supreme#2401. It uses djs V12


# Some Pictures of this bot:

- Help Command

![Help Command](https://media.discordapp.net/attachments/911627187734585413/937639197823602728/unknown.png?width=659&height=434)

- play command

![Play](https://media.discordapp.net/attachments/911627187734585413/937639784870969374/unknown.png)

- play (song name)

![playy](https://media.discordapp.net/attachments/911627187734585413/937640528697249822/unknown.png?width=818&height=434)

- Premium System

![premium](https://media.discordapp.net/attachments/911627187734585413/937641450806595604/unknown.png?width=641&height=434)


## Steps to setup 

- Step 1

If you are replit user then [Click Here](https://repl.it/github/diwasatreya/Lofi-Radio-Music-Bot)

- Step 2 

Change all the emojis id in `emoji.json` file

![Emoji](https://media.discordapp.net/attachments/899947313357791312/937643161268944916/unknown.png?width=584&height=434)

- Step 3

![token](https://media.discordapp.net/attachments/899947313357791312/937643742561701918/unknown.png)

- Step 4 

Run the repo and it takes time to install package then bot will be online

# Developer
- This bot was made by **Supreme#2401** 

![Supreme](https://media.discordapp.net/attachments/911627187734585413/937645307515256872/unknown.png?width=540&height=434)


